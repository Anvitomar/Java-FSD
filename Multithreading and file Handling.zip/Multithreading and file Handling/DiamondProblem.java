package com;

interface interface1 {

public default void display() {
System.out.println("Inside method of First Interface");

}

}

interface interface2 {
public default void display() {
System.out.println("Inside method of second interface");
}
}

public class DiamondProblem implements interface1, interface2 {
public void display() {
interface1.super.display();
interface2.super.display();
}


public static void main(String[] args) {
DiamondProblem obj = new DiamondProblem();
obj.display();
}

}

