package com;
import java.util.Scanner;
	public class ExceptionHandling {
           public static void main(String[] args) {

			int a, b;

			System.out.println("Enter two integers:");

			try {
				Scanner scanner = new Scanner(System.in);
				a = scanner.nextInt();
				b = scanner.nextInt();
			    int c = a / b;
				System.out.println(c);
			} catch (ArithmeticException e) {
				System.out.println("Divsion by zero error occured");
			}
			System.out.println("Continue");

		}

	}
