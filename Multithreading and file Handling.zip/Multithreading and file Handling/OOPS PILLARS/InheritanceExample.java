package com;
import java.util.Scanner;

class A 
{
 int x,y;
 void getValues() 
 {
Scanner sc = new Scanner(System.in);
System.out.println("enter two values:-");
this.x = sc.nextInt();
this.y = sc.nextInt();
}

 void showValues() {
System.out.println("x-:"+this.x+" y-:"+this.y);
}
}

class B extends A {

int sum;

void sum() 
{
this.sum = this.x + this.y;
System.out.println("Sum-:"+sum);
}
}

public class InheritanceExample {
public static void main(String[] args) {

B obj = new B();

obj.getValues();
obj.showValues();
obj.sum();
}
}
