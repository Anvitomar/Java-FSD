package com;

public class EncapsulationExample {

	
		private String name;
		String getName() {
		return name;
		}

		void setName(String name) {
		this.name=name;

		}

        public static void main(String[] args) {
		EncapsulationExample obj = new EncapsulationExample();
		obj.setName("Encapsulation Program");
		System.out.println(obj.getName());
		}
		


	}
