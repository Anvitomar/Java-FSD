import java.util.*;
public class TypeCasting {
	public static void main(String args[])
	{
		System.out.println("Implicit Type Casting Examples");
		
		int a='b';
		System.out.println("Value of a-"+a);
		
		char b='A';
		System.out.println("Value of b-"+b);
		
		float c=b;
		System.out.println("Value of c-"+c);
		
		long d=b;
		System.out.println("Value of d-"+d);
		
		double e=b;
		System.out.println("Value of e-"+e);
		
		System.out.println("Explicit Type Casting Example");
		
		double m =50.2;
		int n=(int)m;
		System.out.println("Value of m-"+m);
		System.out.println("Value of n-"+n);
		
	}

}
