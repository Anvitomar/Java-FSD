class Outer {
    void outerMethod()
    {
        System.out.println("inside outer Method");
        class Inner {
        void innerMethod()
            {
                System.out.println("inside inner Method");
            }
        }
 
        Inner y = new Inner();
        y.innerMethod();
    }
}
public class innerClass {
    public static void main(String[] args)
    {
 
        
        Outer x = new Outer();
        x.outerMethod();
    }
}