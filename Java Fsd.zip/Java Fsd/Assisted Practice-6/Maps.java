import java.util.*;
import java.util.Map.Entry;
public class Maps {
	public static void main(String args[])
	{
		HashMap<Integer,String> hash = new HashMap<Integer,String>();
		hash.put(1,"Red");
		hash.put(2, "Blue");
		hash.put(3, "Black");
		
		System.out.println("\n HashMap Elements ");
		for(Map.Entry m:hash.entrySet()){
			System.out.println(m.getKey()+" "+m.getValue());
			
		}
		Hashtable<Integer,String> h=new Hashtable<Integer,String>();
	    h.put(4,"Grey");
	    h.put(5,"Green");
	    h.put(6,"Yellow");
	    
	    System.out.println("\n HashTable elements ");
	    for(Map.Entry n:h.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }
		      
		      
		      //TreeMap
		      
		      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
		      map.put(7,"Pink");    
		      map.put(8,"Orange");    
		      map.put(9,"White");       
		      
		      System.out.println("\nTreeMap Elements");  
		      for(Map.Entry l:map.entrySet()){    
		       System.out.println(l.getKey()+" "+l.getValue());    
		      }    
		      
		   }  
	}

