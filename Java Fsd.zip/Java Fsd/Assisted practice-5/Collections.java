import java.util.*;
public class Collecions {
	public static void main(String[] args)
	{
	System.out.println("List of array");
	ArrayList<String> color=new ArrayList<String>();
	
	color.add("Red");
	color.add("Blue");
	System.out.println(color);
	
	System.out.println("Creation of a vector");
	Vector<Integer> v=new Vector();
	 v.addElement(20);
	 v.addElement(30);
	 System.out.println(v);
	 
	 System.out.println("Creation of LinkedList");
	 LinkedList<String> names=new LinkedList<String>();
	 names.add("Anvi");
	 names.add("Srasthi");
	 Iterator<String> it =names.iterator();
	 while(it.hasNext()) {
		 System.out.println(it.next());
		 
	System.out.println("Creation of HashSet");
	HashSet<Integer>set=new HashSet<Integer>();
	set.add(200);
	set.add(201);
	set.add(202);
	set.add(204);
	System.out.println(set);
	
	System.out.println("Creation of LinkedHashSet");
	LinkedHashSet<Integer>set1=new LinkedHashSet<Integer>();
	set1.add(10);
	set1.add(13);
	set1.add(15);
	set1.add(16);
	System.out.println(set1);
		 
	 }
	}
}


