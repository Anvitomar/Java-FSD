public class methodCalling {
	int val=100;

	int operation(int val) {
		val =val*10/100;
		return(val);
	}
 }

  class overloadMethod {
		public void area(int b,int h)
	    {
	         System.out.println("Area of Rectangle : "+(b*h));
	    }
	    public void area(int r) 
	    {
	         System.out.println("Area of a square"+(r*r));
	    }

  }



class methodExecution {

public int sum(int a,int b) {
	int z=a+b;
	return z;
}

public static void main(String[] args) {

	methodExecution b=new methodExecution();
	int ans= b.sum(10,3);
	System.out.println("Sum is :"+ans);
	
	methodCalling d = new methodCalling();
	System.out.println("Before operation "+d.val);
	d.operation(100);
	System.out.println("After operation "+d.val);
	
	overloadMethod ob=new overloadMethod();
    ob.area(11,10);
    ob.area(10);  
	}
}
}