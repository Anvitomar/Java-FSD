package PublicSpecifiers;
public class Public {

	public void display() {
		System.out.println("Usage of public access specifiers ");
	}
	
}
