package PrivateSpecifiers;

public class Private {
	private void display() {
		System.out.println("Usage of Private Access Specifiers");
	}
	public static void main(String[] args) {
		Private a = new Private();
		a.display();
	}

}
