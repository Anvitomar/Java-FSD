package PublicSpecifiers2;
import PublicSpecifiers.*;

public class Public2 {

	public static void main(String[] args) {
		Public s = new Public();
		s.display();
		
	}
}
