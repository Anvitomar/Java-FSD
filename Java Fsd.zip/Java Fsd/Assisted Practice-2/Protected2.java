package ProtectedSpecifiers;

public class Protected2 extends Protected {
	public static void main(String[] args) {
		Protected s = new Protected();
		s.display();
	}

}
