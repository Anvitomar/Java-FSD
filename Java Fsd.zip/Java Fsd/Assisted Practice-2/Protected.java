package ProtectedSpecifiers;

public class Protected {
	protected void display() {
		System.out.println("Usage of Protected Access specifiers");
		
	}

}
