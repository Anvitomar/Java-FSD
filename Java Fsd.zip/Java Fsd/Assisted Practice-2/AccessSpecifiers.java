package DefaultSpecifiers;
public class AccessSpecifiers {
 
  void display() 
     { 
         System.out.println("Usage of Default Access Specifiers"); 
     } 



	public static void main(String[] args) {
		//default
		System.out.println("Dafault Access Specifier");
		AccessSpecifiers obj = new AccessSpecifiers(); 		  
        obj.display(); 

	}
}

