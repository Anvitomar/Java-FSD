package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetPost
 */
public class GetPost extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetPost() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	PrintWriter pw=response.getWriter();
	String username=request.getParameter("uname");
	String password=request.getParameter("pwd");
	
	if(username.equals("pqrs")&& password.equals("1234")) {
		pw.print("Successfully login with get method");
	}else {
		pw.print("Failure!!Try once again");
	}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	PrintWriter pw=response.getWriter();
	String username=request.getParameter("uname");
	String password=request.getParameter("pwd");
	
	if(username.equals("abcd")&&password.equals("12345")) {
		pw.print("Successfully login with post method");
	}
	else {
		pw.print("Failure!Try once agaon..!!");
	}
	
	
	
	}

}
