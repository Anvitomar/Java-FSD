package com;

public class Range {
	static int a = 16;
    static int b = 100000; 
    static long table[][] = new long[b][a + 1]; 
    static void BuildTable(int ar[], int n) 
    { 
        for (int i = 0; i < n; i++) 
            table[i][0] = ar[i]; 
        for (int j = 1; j <= a; j++) 
            for (int i = 0; i <= n - (1 << j); i++) 
                table[i][j] = table[i][j - 1] + table[i + (1 << (j - 1))][j - 1]; 
    } 
    static long query(int x, int y) 
    {
        long answer = 0; 
        for (int j = a; j >= 0; j--)  
        { 
            if (x + (1 << j) - 1 <= y)  
            { 
                answer = answer + table[x][j];
                x += 1 << j; 
            } 
        } 
        return answer; 
    }
    public static void main(String args[]) 
    { 
        int ar[] = {6,3,8,9,5,2}; 
        int n = ar.length; 
        BuildTable(ar, n); 
        System.out.println(query(0, 5)); 
        System.out.println(query(3, 5)); 
        System.out.println(query(2, 4)); 
    } 
}


	