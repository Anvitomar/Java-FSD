package com;

class Rotate { 
	public void rotate(int[] num, int n) {
			if(n > num.length) 
			       			n=n%num.length;
			 		int[] out = new int[num.length];
			 		for(int i=0; i < n; i++){
			        			out[i] = num[num.length-n+i];
			 		}
			 		int j=0;
			    		for(int i=n; i<num.length; i++){
			        			out[i] = num[j];
			j++;
			    		}
			 		System.arraycopy( out, 0, num, 0, num.length );
			}
			} 

public class ArrayRotatn {
public static void main(String[] args) {
Rotate r = new Rotate();
int ar[] = { 4,5,2,8,9,1,7}; 
		r.rotate(ar,4); 
      for(int i=0;i<ar.length;i++)
      {
	  System.out.print(ar[i]+" ");
			   }
		}
}

