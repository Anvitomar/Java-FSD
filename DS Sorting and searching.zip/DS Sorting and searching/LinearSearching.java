package com;

public class LinearSearching {

	public static void main(String args[]){
	      int array[] = {12,16,11,32};
	      int size = array.length;
	      int value = 32;
	      int s=0;

	      for (int i=0 ;i< size; i++){
	         if(array[i]==value){
	            System.out.println("Found at index :"+ i);
	            s+=1;
	         }
	         
	      }
	      if(s==0) {
	     	 System.out.println("Not found");
	      }
	   }
	}