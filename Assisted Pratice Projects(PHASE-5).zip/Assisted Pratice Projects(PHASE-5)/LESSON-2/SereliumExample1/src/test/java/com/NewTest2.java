package com;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class NewTest2 {
	public String baseUrl = "https://login.yahoo.com/";
	String driverPath="D:\\mysql/chromedriver.exe";
	public WebDriver driver;
  @Test
  public void f() {
	  // set the system property for chrome driver
	  System.setProperty("webdriver.chrome.driver", driverPath);
	  //create the object  for chrome browser
	  driver  = new ChromeDriver();
	  driver.get(baseUrl);
	  List<WebElement> allInputElements = driver.findElements(By.tagName("div"));
	  for(WebElement e: allInputElements)
	  {
		  System.out.println(e.getAttribute("id")); //<input type=" " id=""
	  }
  }
  @BeforeTest
  public void beforeTest() {
	  System.out.println("Before testcase");
  }

  @AfterTest
  public void afterTest() {
	  driver.quit();
	  System.out.println("After testcase");
  }

}
