package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class XpathExample {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "D:\\\\mysql/chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://login.yahoo.com/account/create");
	  driver.findElement(By.xpath("//input[@id='usernamereg-firstName']")).sendKeys("PRince");
  }
}
