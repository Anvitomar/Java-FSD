package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class NewTest7 {
	@Test
	public void login() {
		System.setProperty("webdriver.chrome.driver", "D:\\\\mysql/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http://localhost:8080/SereliumExample1/");
		
		WebElement username = driver.findElement(By.id("Uname"));
		WebElement password = driver.findElement(By.id("pass"));
		WebElement login = driver.findElement(By.id("btn"));
		
		username.clear();
		username.click();
		username.sendKeys("abc@gmail.com");
		
		password.clear();
		password.click();
		password.sendKeys("123");
		//driver.switchTo().alert().dismiss();
		login.click();
		
		String actualUrl = "https://live.browserstack.com/dashboard";
		String expectedUrl = driver.getCurrentUrl();
		Assert.assertEquals(expectedUrl, actualUrl);
	}
}

