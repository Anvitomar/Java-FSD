package com;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import org.testng.annotations.AfterTest;

public class NewTest1 {
	String driverPath="D:\\mysql/chromedriver.exe";
	public WebDriver driver;
  @Test
  public void f() throws InterruptedException{
	  driver.get("http://login.yahoo.com/");
	  System.out.println("the tittle of the page is: "+driver.getTitle());
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","D:\\\\mysql/chromedriver.exe");
	  driver=new ChromeDriver();
  }

  @AfterTest
  public void afterTest() {

	  driver.close();
  }
}
