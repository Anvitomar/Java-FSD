package com.business;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class NewTest1 {
	String driverPath =("F:\\Java_FSD\\Phase_5\\New folder/chromedriver.exe");
	public WebDriver driver;
	
  @Test
  public void f() throws InterruptedException{
	  driver.get("https://www.ebay.com/");
	  System.out.println("The  title of the page "+driver.getTitle());
  }
  @BeforeTest
  public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver","F:\\Java_FSD\\Phase_5\\New folder/chromedriver.exe");
	  
	  driver = new ChromeDriver();
  }

  @AfterTest
  public void afterTest() {
	  driver.close();
  }

}
