package com.business;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Xpath {
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "F:\\Java_FSD\\Phase_5\\New folder/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://login.yahoo.com/account/create");
		driver.findElement(By.xpath("//input[@id='usernamereg-firstName']")).sendKeys("AbbaJabba");
  }
  @BeforeTest
  public void beforeTest() {
  }

  @AfterTest
  public void afterTest() {
  }

}
